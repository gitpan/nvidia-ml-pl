nvidia::ml - Perl bindings to NVML, the NVIDIA Management Library

To install:
perl Makefile.PL
make
make test
make install

Read perldoc perlmodinstall for more information about installing

Run `perldoc nvidia::ml` for information about the module after installation

